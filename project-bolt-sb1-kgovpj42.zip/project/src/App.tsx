import Navbar from './components/Navbar';
import Hero from './components/Hero';
import LiveDemo from './components/LiveDemo';
import HowItWorks from './components/HowItWorks';
import Benefits from './components/Benefits';
import TargetAudience from './components/TargetAudience';
import Testimonials from './components/Testimonials';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import FloatingCTA from './components/FloatingCTA';

function App() {
  return (
    <div className="bg-black text-white overflow-x-hidden">
      <Navbar />
      <Hero />
      <LiveDemo />
      <HowItWorks />
      <Benefits />
      <TargetAudience />
      <Testimonials />
      <FinalCTA />
      <Footer />
      <FloatingCTA />
    </div>
  );
}

export default App;
