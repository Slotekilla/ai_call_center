export default function Footer() {
  return (
    <footer
      className="border-t py-10 px-6"
      style={{ borderColor: 'rgba(255,255,255,0.07)', background: '#000' }}
    >
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-white flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
              <path d="M2 4C2 2.9 2.9 2 4 2h8c1.1 0 2 .9 2 2v5c0 1.1-.9 2-2 2H9l-3 3v-3H4c-1.1 0-2-.9-2-2V4z" fill="#000"/>
            </svg>
          </div>
          <span className="text-white/70 font-semibold text-sm">Vocall</span>
          <span className="text-white/20 text-sm ml-4">© 2025</span>
        </div>

        <nav className="flex items-center gap-6">
          <a
            href="mailto:info@vocall.si"
            className="text-white/40 hover:text-white text-sm font-medium transition-colors"
          >
            Kontakt
          </a>
          <a
            href="#"
            className="text-white/40 hover:text-white text-sm font-medium transition-colors"
          >
            Pogoji
          </a>
          <a
            href="#"
            className="text-white/40 hover:text-white text-sm font-medium transition-colors"
          >
            Zasebnost
          </a>
        </nav>
      </div>
    </footer>
  );
}
