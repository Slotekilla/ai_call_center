import { PhoneCall, Calendar } from 'lucide-react';
import WaveformAnimation from './WaveformAnimation';

export default function Hero() {
  return (
    <section
      className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 overflow-hidden"
      style={{
        background: 'radial-gradient(ellipse 80% 60% at 50% -10%, rgba(255,255,255,0.08) 0%, transparent 60%), #000',
      }}
    >
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.5) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.5) 1px, transparent 1px)',
          backgroundSize: '60px 60px',
        }}
        aria-hidden="true"
      />

      <div className="relative z-10 max-w-4xl mx-auto pt-32 pb-20">
        <div className="animate-fade-in-up">
          <span className="inline-block text-xs font-semibold tracking-widest text-white/40 uppercase mb-6 border border-white/10 rounded-full px-4 py-2">
            AI-powered Call Center
          </span>
        </div>

        <h1
          className="animate-fade-in-up delay-100 text-5xl sm:text-6xl md:text-7xl lg:text-[80px] font-black leading-[1.05] tracking-tight text-white mb-6"
        >
          Tvoj call center.
          <br />
          <span
            style={{
              background: 'linear-gradient(135deg, #fff 30%, rgba(255,255,255,0.45) 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Popolnoma avtomatiziran.
          </span>
        </h1>

        <p className="animate-fade-in-up delay-200 text-lg md:text-xl text-white/55 font-light max-w-2xl mx-auto mb-10 leading-relaxed">
          AI agenti, ki odgovarjajo na klice, kvalificirajo stranke in jih pretvorijo v
          priložnosti&nbsp;— <span className="text-white/80 font-medium">24/7.</span>
        </p>

        <div className="animate-fade-in-up delay-300 flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a href="#demo" className="btn-primary text-base px-7 py-4 w-full sm:w-auto justify-center">
            <PhoneCall size={18} />
            Preizkusi AI agenta
          </a>
          <a href="tel:+38651000000" className="btn-secondary text-base px-7 py-4 w-full sm:w-auto justify-center">
            <Calendar size={18} />
            Rezerviraj klic
          </a>
        </div>

        <div className="animate-fade-in delay-500">
          <div
            className="mx-auto rounded-2xl border border-white/10 overflow-hidden"
            style={{
              background: 'rgba(255,255,255,0.03)',
              maxWidth: '480px',
              padding: '20px 24px',
            }}
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full bg-white/20" />
                <span className="w-3 h-3 rounded-full bg-white/20" />
                <span className="w-3 h-3 rounded-full bg-white/20" />
              </div>
              <span className="text-white/30 text-xs font-mono">live call · 00:34</span>
              <div className="ml-auto flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
                <span className="text-green-400 text-xs font-medium">V živo</span>
              </div>
            </div>
            <WaveformAnimation bars={32} height={56} />
            <p className="text-white/40 text-xs text-center mt-3 font-mono">
              "Pozdravljeni, sem Ana iz podjetja Vocall..."
            </p>
          </div>
        </div>

        <div className="animate-fade-in delay-700 mt-12 flex flex-col sm:flex-row items-center justify-center gap-6 text-white/35 text-sm">
          <span className="flex items-center gap-2">
            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5"/><path d="M5 8l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Brez pogodbe
          </span>
          <span className="flex items-center gap-2">
            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5"/><path d="M5 8l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Zagon v 48 urah
          </span>
          <span className="flex items-center gap-2">
            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><circle cx="8" cy="8" r="7" stroke="currentColor" strokeWidth="1.5"/><path d="M5 8l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
            Brezplačen test
          </span>
        </div>
      </div>

      <div
        className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none"
        style={{
          background: 'linear-gradient(to bottom, transparent, #000)',
        }}
        aria-hidden="true"
      />
    </section>
  );
}
