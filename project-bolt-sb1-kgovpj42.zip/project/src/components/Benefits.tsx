import { PhoneMissed, Filter, DollarSign, Clock, TrendingUp } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const benefits = [
  {
    icon: PhoneMissed,
    title: 'Nikoli več ne zamudiš klica',
    description:
      'Vsak dohodni klic je sprejet v manj kot sekundi. Nič več izgubljenih strank zaradi zasedene linije ali odsotnosti.',
  },
  {
    icon: Filter,
    title: 'Samodejna kvalifikacija leadov',
    description:
      'AI razvrsti stranke po kakovosti in toplini. Tvoja prodajna ekipa se ukvarja samo z resnimi kupci.',
  },
  {
    icon: DollarSign,
    title: 'Prihraniš čas in stroške',
    description:
      'Odpadejo stroški call centra, usposabljanje in fluktuacija zaposlenih. Mesečni prihranek od 2.000 € naprej.',
  },
  {
    icon: Clock,
    title: 'Deluje 24/7 brez ekipe',
    description:
      'AI agent je vedno dosegljiv — ob vikendih, praznikih, ponoči. Nobena stranka ne odide k konkurenci.',
  },
  {
    icon: TrendingUp,
    title: 'Skalira brez dodatnih zaposlitev',
    description:
      'Hkrati sprejme sto klicev. Ko raste tvoje podjetje, raste sistem — brez novih zaposlitev.',
  },
];

export default function Benefits() {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <section
      id="prednosti"
      className="py-24 md:py-32 px-6"
      style={{ background: '#050505' }}
    >
      <div ref={ref} className={`max-w-6xl mx-auto section-enter ${isVisible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="inline-block text-xs font-semibold tracking-widest text-white/40 uppercase border border-white/10 rounded-full px-4 py-2 mb-6">
            Prednosti
          </span>
          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tight">
            Vse kar pogrešaš v
            <br />
            <span
              style={{
                background: 'linear-gradient(135deg, #fff 30%, rgba(255,255,255,0.4) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              svojem call centru
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="glass-card p-7 flex flex-col gap-4 group"
                style={{
                  gridColumn: index === 4 ? 'span 1' : undefined,
                }}
              >
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
                  style={{
                    background: 'rgba(255,255,255,0.07)',
                    border: '1px solid rgba(255,255,255,0.1)',
                  }}
                >
                  <Icon size={20} className="text-white/80" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-lg mb-2 leading-snug">{benefit.title}</h3>
                  <p className="text-white/45 text-sm leading-relaxed">{benefit.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
