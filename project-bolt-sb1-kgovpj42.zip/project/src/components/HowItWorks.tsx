import { PhoneIncoming, MessageCircle, BarChart3, ArrowRight } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const steps = [
  {
    number: '01',
    icon: PhoneIncoming,
    title: 'Stranka pokliče tvojo številko',
    description: 'AI agent sprejme vsak klic takoj — brez čakalne vrste, brez zamud, kadarkoli.',
    detail: 'Integracija z obstoječo telefonsko številko v < 24h',
  },
  {
    number: '02',
    icon: MessageCircle,
    title: 'AI se oglasi takoj in govori naravno',
    description: 'Naravno glasovno pogovarjanje brez robotskega zvena. Stranka ne ve, da govori z AI.',
    detail: 'Podpira slovenščino in angleščino',
  },
  {
    number: '03',
    icon: BarChart3,
    title: 'AI postavi prava vprašanja',
    description: 'Zbira ključne informacije: potrebo, časovni okvir in proračun stranke.',
    detail: 'Prilagodljiv skript za vsako industrijo',
  },
  {
    number: '04',
    icon: ArrowRight,
    title: 'AI usmeri naprej avtomatično',
    description:
      'HOT leadi → rezervacija klica. WARM leadi → e-mail follow-up. COLD leadi → nurture sekvenca.',
    detail: 'Integracija s CRM sistemi po vaši izbiri',
  },
];

export default function HowItWorks() {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <section id="kako-deluje" className="py-24 md:py-32 px-6 bg-black">
      <div ref={ref} className={`max-w-6xl mx-auto section-enter ${isVisible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="inline-block text-xs font-semibold tracking-widest text-white/40 uppercase border border-white/10 rounded-full px-4 py-2 mb-6">
            Kako deluje
          </span>
          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tight">
            Od klica do leads v
            <br />
            <span
              style={{
                background: 'linear-gradient(135deg, #fff 30%, rgba(255,255,255,0.4) 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                backgroundClip: 'text',
              }}
            >
              štirih korakih
            </span>
          </h2>
        </div>

        <div className="relative">
          <div
            className="hidden lg:block absolute left-[calc(50%-1px)] top-0 bottom-0 w-px"
            style={{ background: 'linear-gradient(to bottom, transparent, rgba(255,255,255,0.1) 20%, rgba(255,255,255,0.1) 80%, transparent)' }}
            aria-hidden="true"
          />

          <div className="space-y-6 lg:space-y-0">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isLeft = index % 2 === 0;

              return (
                <div
                  key={step.number}
                  className={`lg:flex items-center gap-8 lg:gap-16 ${
                    isLeft ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                  style={{ marginBottom: index < steps.length - 1 ? '48px' : 0 }}
                >
                  <div className={`flex-1 ${isLeft ? 'lg:text-right' : 'lg:text-left'}`}>
                    <div
                      className="glass-card p-7 inline-block w-full text-left"
                      style={{ maxWidth: '420px', float: isLeft ? 'right' : 'left' }}
                    >
                      <div className="flex items-start gap-4">
                        <div
                          className="w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center"
                          style={{
                            background: 'rgba(255,255,255,0.07)',
                            border: '1px solid rgba(255,255,255,0.1)',
                          }}
                        >
                          <Icon size={18} className="text-white/80" />
                        </div>
                        <div>
                          <div className="text-white/25 text-xs font-mono mb-1">Korak {step.number}</div>
                          <h3 className="text-white font-bold text-lg leading-snug mb-2">
                            {step.title}
                          </h3>
                          <p className="text-white/50 text-sm leading-relaxed mb-3">
                            {step.description}
                          </p>
                          <span className="text-xs text-white/30 font-medium border border-white/10 rounded-full px-3 py-1">
                            {step.detail}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="hidden lg:flex w-12 h-12 flex-shrink-0 items-center justify-center rounded-full z-10"
                    style={{
                      background: 'rgba(255,255,255,0.07)',
                      border: '1px solid rgba(255,255,255,0.15)',
                    }}
                  >
                    <span className="text-white font-black text-sm">{step.number}</span>
                  </div>

                  <div className="flex-1 hidden lg:block" />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
