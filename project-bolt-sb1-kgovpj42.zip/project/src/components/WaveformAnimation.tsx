import { useMemo } from 'react';

interface WaveformAnimationProps {
  bars?: number;
  height?: number;
  className?: string;
}

export default function WaveformAnimation({ bars = 28, height = 64, className = '' }: WaveformAnimationProps) {
  const barData = useMemo(() => {
    return Array.from({ length: bars }, (_, i) => ({
      id: i,
      duration: 0.7 + (i % 5) * 0.18,
      delay: i * 0.06,
      maxH: 30 + ((i * 17 + 11) % 70),
    }));
  }, [bars]);

  return (
    <div
      className={`flex items-center justify-center gap-[3px] ${className}`}
      style={{ height }}
      aria-hidden="true"
    >
      {barData.map((bar) => (
        <div
          key={bar.id}
          className="rounded-full bg-white"
          style={{
            width: '3px',
            height: `${bar.maxH}%`,
            animation: `waveBar ${bar.duration}s ease-in-out infinite alternate`,
            animationDelay: `${bar.delay}s`,
            transformOrigin: 'center',
          }}
        />
      ))}
    </div>
  );
}
