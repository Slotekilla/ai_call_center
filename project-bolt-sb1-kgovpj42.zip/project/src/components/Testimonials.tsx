import { Quote } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const testimonials = [
  {
    quote: 'Imel sem občutek, kot da govorim s pravo osebo. Sploh nisem vedel, da je AI.',
    name: 'Marko P.',
    role: 'Lastnik avtoservisa',
    initials: 'MP',
  },
  {
    quote: 'Nadomestili smo 2 agenta s tem sistemom. Stroški so padli za 60%, kakovost pa je ostala.',
    name: 'Nina K.',
    role: 'Direktorica marketinške agencije',
    initials: 'NK',
  },
  {
    quote: 'Kvaliteta leadov se je občutno izboljšala. Zdaj govorimo samo z resnimi kupci.',
    name: 'Aleš M.',
    role: 'Vodja prodaje, nepremičnine',
    initials: 'AM',
  },
];

export default function Testimonials() {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <section
      className="py-24 md:py-32 px-6"
      style={{ background: '#050505' }}
    >
      <div ref={ref} className={`max-w-6xl mx-auto section-enter ${isVisible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="inline-block text-xs font-semibold tracking-widest text-white/40 uppercase border border-white/10 rounded-full px-4 py-2 mb-6">
            Mnenja
          </span>
          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tight">
            Kar pravijo naše stranke
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, index) => (
            <div
              key={index}
              className="glass-card p-8 flex flex-col"
              style={{
                animationDelay: `${index * 0.1}s`,
              }}
            >
              <Quote size={24} className="text-white/20 mb-5 flex-shrink-0" />
              <p className="text-white/75 text-lg leading-relaxed mb-8 flex-1 font-light">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3 border-t border-white/[0.06] pt-6">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white flex-shrink-0"
                  style={{ background: 'rgba(255,255,255,0.1)' }}
                >
                  {t.initials}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.name}</div>
                  <div className="text-white/40 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-center gap-8 text-white/25">
          <div className="text-center">
            <div className="text-3xl font-black text-white">97%</div>
            <div className="text-sm mt-1">zadovoljnih strank</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-white/10" />
          <div className="text-center">
            <div className="text-3xl font-black text-white">3.2×</div>
            <div className="text-sm mt-1">več kvalificiranih leadov</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-white/10" />
          <div className="text-center">
            <div className="text-3xl font-black text-white">60%</div>
            <div className="text-sm mt-1">nižji stroški</div>
          </div>
          <div className="hidden sm:block w-px h-12 bg-white/10" />
          <div className="text-center">
            <div className="text-3xl font-black text-white">48h</div>
            <div className="text-sm mt-1">do zagonа</div>
          </div>
        </div>
      </div>
    </section>
  );
}
