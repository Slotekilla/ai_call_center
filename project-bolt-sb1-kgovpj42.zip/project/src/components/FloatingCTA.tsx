import { PhoneCall } from 'lucide-react';
import { useNavScroll } from '../hooks/useScrollAnimation';

export default function FloatingCTA() {
  const { pastHero } = useNavScroll();

  return (
    <div
      className="fixed bottom-6 left-1/2 z-40 transition-all duration-500"
      style={{
        transform: pastHero
          ? 'translateX(-50%) translateY(0)'
          : 'translateX(-50%) translateY(120px)',
        opacity: pastHero ? 1 : 0,
        pointerEvents: pastHero ? 'auto' : 'none',
      }}
    >
      <div
        className="flex items-center gap-3 rounded-2xl px-5 py-3 shadow-2xl"
        style={{
          background: 'rgba(10,10,10,0.95)',
          border: '1px solid rgba(255,255,255,0.15)',
          backdropFilter: 'blur(20px)',
        }}
      >
        <div className="flex items-center gap-2 text-white/50 text-sm">
          <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          AI agent je dosegljiv
        </div>
        <div className="w-px h-5 bg-white/10" />
        <a
          href="#demo"
          className="flex items-center gap-2 bg-white text-black text-sm font-bold px-4 py-2 rounded-xl hover:bg-gray-100 transition-colors"
        >
          <PhoneCall size={14} />
          Preizkusi zdaj
        </a>
      </div>
    </div>
  );
}
