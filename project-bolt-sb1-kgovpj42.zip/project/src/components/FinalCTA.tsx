import { PhoneCall, Calendar } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import WaveformAnimation from './WaveformAnimation';

export default function FinalCTA() {
  const { ref, isVisible } = useScrollAnimation(0.15);

  return (
    <section
      className="py-24 md:py-32 px-6 overflow-hidden"
      style={{
        background: 'radial-gradient(ellipse 80% 60% at 50% 100%, rgba(255,255,255,0.06) 0%, transparent 70%), #000',
      }}
    >
      <div
        ref={ref}
        className={`max-w-4xl mx-auto text-center section-enter ${isVisible ? 'visible' : ''}`}
      >
        <div className="mb-8">
          <WaveformAnimation bars={20} height={40} className="opacity-30" />
        </div>

        <h2 className="text-4xl md:text-6xl font-black text-white mb-6 tracking-tight leading-tight">
          Pusti AI-ju, da sprejema
          <br />
          <span
            style={{
              background: 'linear-gradient(135deg, #fff 20%, rgba(255,255,255,0.45) 100%)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            tvoje klice
          </span>
        </h2>

        <p className="text-white/50 text-lg max-w-lg mx-auto mb-10 leading-relaxed">
          Brezplačna demo verzija za 14 dni. Brez pogodbe, brez tveganja.
          Začni danes in vidi rezultate do konca tedna.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-10">
          <a href="#demo" className="btn-primary text-base px-8 py-4 w-full sm:w-auto justify-center">
            <PhoneCall size={18} />
            Preizkusi zdaj
          </a>
          <a href="tel:+38651000000" className="btn-secondary text-base px-8 py-4 w-full sm:w-auto justify-center">
            <Calendar size={18} />
            Rezerviraj termin
          </a>
        </div>

        <p className="text-white/20 text-sm">
          Zagon v 48 urah &middot; Brez pogodbe &middot; Polna podpora
        </p>
      </div>
    </section>
  );
}
