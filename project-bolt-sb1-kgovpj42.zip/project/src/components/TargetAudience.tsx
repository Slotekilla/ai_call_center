import { Megaphone, Home, Wrench, ShoppingCart, Users } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';

const audiences = [
  {
    icon: Megaphone,
    title: 'Marketing agencije',
    description: 'Avtomatiziraj kvalifikacijo inbound leadov za vse tvoje stranke.',
  },
  {
    icon: Home,
    title: 'Nepremičnine',
    description: 'Vsak povpraševalec je takoj ocenjen — resni kupci dobijo takojšen odziv.',
  },
  {
    icon: Wrench,
    title: 'Servisne dejavnosti',
    description: 'Avtomatično sprejemanje rezervacij in triažiranje urgentnih klicev.',
  },
  {
    icon: ShoppingCart,
    title: 'E-commerce',
    description: 'Reševanje vprašanj, preverjanje naročil in podpora strankam po klicu.',
  },
  {
    icon: Users,
    title: 'Prodajne ekipe',
    description: 'Predkvalificirni pipeline in zapolni koledar tvojih prodajalcev.',
  },
];

export default function TargetAudience() {
  const { ref, isVisible } = useScrollAnimation(0.1);

  return (
    <section className="py-24 md:py-32 px-6 bg-black">
      <div ref={ref} className={`max-w-6xl mx-auto section-enter ${isVisible ? 'visible' : ''}`}>
        <div className="text-center mb-16">
          <span className="inline-block text-xs font-semibold tracking-widest text-white/40 uppercase border border-white/10 rounded-full px-4 py-2 mb-6">
            Za koga je
          </span>
          <h2 className="text-4xl md:text-5xl font-black text-white tracking-tight">
            Rešitev za vsako panogo
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {audiences.map((audience, index) => {
            const Icon = audience.icon;
            return (
              <div
                key={index}
                className="group relative rounded-2xl p-6 overflow-hidden cursor-default transition-all duration-300"
                style={{
                  background: 'rgba(255,255,255,0.02)',
                  border: '1px solid rgba(255,255,255,0.07)',
                }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                  (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.15)';
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-3px)';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.02)';
                  (e.currentTarget as HTMLDivElement).style.borderColor = 'rgba(255,255,255,0.07)';
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)';
                }}
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4"
                  style={{
                    background: 'rgba(255,255,255,0.06)',
                    border: '1px solid rgba(255,255,255,0.1)',
                  }}
                >
                  <Icon size={22} className="text-white/70" />
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{audience.title}</h3>
                <p className="text-white/45 text-sm leading-relaxed">{audience.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
