import { useEffect } from 'react';
import { Mic, PhoneCall } from 'lucide-react';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import WaveformAnimation from './WaveformAnimation';

declare global {
  interface Window {
    vapiSDK?: {
      run: (config: { apiKey: string; assistant: string; config?: Record<string, unknown> }) => void;
    };
  }
}

export default function LiveDemo() {
  const { ref, isVisible } = useScrollAnimation(0.1);

  useEffect(() => {
    const initializeVapi = () => {
      if (window.vapiSDK) {
        window.vapiSDK.run({
          apiKey: 'ed676b6a-b8ba-419d-afd1-ee3127453d10',
          assistant: '5530f5e2-4abb-40c2-af37-b727dae5e5a2',
          config: {
            position: 'bottom-right',
            theme: {
              primary: '#111827',
              secondary: '#ffffff',
            },
          },
        });
      }
    };

    if (window.vapiSDK) {
      initializeVapi();
    } else {
      window.addEventListener('load', initializeVapi);
      return () => window.removeEventListener('load', initializeVapi);
    }
  }, []);

  return (
    <section
      id="demo"
      className="py-24 md:py-32 px-6"
      style={{
        background: 'radial-gradient(ellipse 100% 80% at 50% 50%, rgba(255,255,255,0.04) 0%, transparent 70%), #030303',
      }}
    >
      <div
        ref={ref}
        className={`max-w-4xl mx-auto section-enter ${isVisible ? 'visible' : ''}`}
      >
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 text-xs font-semibold tracking-widest text-white/40 uppercase border border-white/10 rounded-full px-4 py-2 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
            Live demo
          </div>
          <h2 className="text-4xl md:text-5xl font-black text-white mb-5 tracking-tight">
            Preizkusi AI agenta v živo
          </h2>
          <p className="text-white/55 text-lg max-w-xl mx-auto leading-relaxed">
            Klikni spodaj in se pogovarjaj z našim AI agentom. Postavljal ti bo vprašanja in te
            kvalificiral kot pravi prodajni asistent.
          </p>
        </div>

        <div
          className="relative rounded-3xl overflow-hidden border border-white/10"
          style={{ background: 'rgba(255,255,255,0.02)' }}
        >
          <div
            className="absolute inset-0 opacity-30"
            style={{
              background:
                'radial-gradient(ellipse 60% 50% at 50% 0%, rgba(255,255,255,0.06) 0%, transparent 60%)',
            }}
            aria-hidden="true"
          />

          <div className="relative z-10 p-8 md:p-12 text-center">
            <div className="flex justify-center mb-8">
              <div className="relative">
                <div
                  className="absolute inset-0 rounded-full"
                  style={{
                    animation: 'pulse-ring 2s cubic-bezier(0.215,0.61,0.355,1) infinite',
                    border: '1px solid rgba(255,255,255,0.3)',
                    transform: 'scale(1)',
                  }}
                />
                <div
                  className="relative w-24 h-24 rounded-full flex items-center justify-center"
                  style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.15) 0%, rgba(255,255,255,0.05) 100%)',
                    border: '1px solid rgba(255,255,255,0.2)',
                  }}
                >
                  <PhoneCall size={36} className="text-white" />
                </div>
              </div>
            </div>

            <WaveformAnimation bars={24} height={48} className="mb-8 opacity-60" />

            <h3 className="text-2xl font-bold text-white mb-3">
              Pokliči AI agenta zdaj
            </h3>
            <p className="text-white/50 mb-8 max-w-md mx-auto">
              Klikni gumb v spodnjem desnem kotu, da začneš pogovor z AI agentom.
              Demo je brezplačen in ne zahteva registracije.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <div
                className="flex items-center gap-3 px-6 py-4 rounded-xl"
                style={{
                  background: 'rgba(255,255,255,0.05)',
                  border: '1px solid rgba(255,255,255,0.1)',
                }}
              >
                <Mic size={20} className="text-white/70" />
                <span className="text-white/70 text-sm font-medium">
                  Klikni na modri gumb (spodaj desno) za začetek
                </span>
              </div>
            </div>

            <div className="mt-10 grid grid-cols-3 gap-4">
              {[
                { label: 'Odzivni čas', value: '< 1s' },
                { label: 'Jeziki', value: 'SLO / EN' },
                { label: 'Razpoložljivost', value: '24/7' },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-xl p-4"
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid rgba(255,255,255,0.07)',
                  }}
                >
                  <div className="text-2xl font-black text-white mb-1">{stat.value}</div>
                  <div className="text-white/40 text-xs">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <p className="text-center text-white/25 text-xs mt-6">
          Demonstracijski klic je brezplačen. Vaši podatki so varni in ne bodo shranjeni.
        </p>
      </div>
    </section>
  );
}
