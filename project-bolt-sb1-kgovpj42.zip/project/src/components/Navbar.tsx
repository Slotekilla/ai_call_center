import { useNavScroll } from '../hooks/useScrollAnimation';

export default function Navbar() {
  const { scrolled } = useNavScroll();

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 nav-blur ${
        scrolled
          ? 'bg-black/90 border-b border-white/10'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
              <path d="M2 4C2 2.9 2.9 2 4 2h8c1.1 0 2 .9 2 2v5c0 1.1-.9 2-2 2H9l-3 3v-3H4c-1.1 0-2-.9-2-2V4z" fill="#000"/>
            </svg>
          </div>
          <span className="text-white font-bold text-lg tracking-tight">Vocall</span>
        </div>

        <div className="hidden md:flex items-center gap-8">
          <a href="#kako-deluje" className="text-white/60 hover:text-white text-sm font-medium transition-colors">Kako deluje</a>
          <a href="#prednosti" className="text-white/60 hover:text-white text-sm font-medium transition-colors">Prednosti</a>
          <a href="#demo" className="text-white/60 hover:text-white text-sm font-medium transition-colors">Demo</a>
        </div>

        <div className="flex items-center gap-3">
          <a href="#demo" className="hidden sm:block text-sm text-white/70 hover:text-white font-medium transition-colors">
            Demo
          </a>
          <a href="tel:+38651000000" className="btn-primary text-sm py-2 px-4">
            Rezerviraj klic
          </a>
        </div>
      </div>
    </nav>
  );
}
